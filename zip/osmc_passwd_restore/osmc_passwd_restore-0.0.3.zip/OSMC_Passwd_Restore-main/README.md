# osmc_passwd_restore
A simple addon to factory restore osmc user password.
