service.osmc.tts
================

Based on Text to speech for Kodi (XBMC)
------------------------------
Adds speech to Kodi. It does this by using the predetermined speech engines for the particular platform, and aims to
work 'out of the box' as much as possible.

This fork is going to be tweaked more an more to be a "ready to deploy" zip for autoated OSMC package install.
This is based on pvagners 2to3 branch to get Matrix compabillity.

