# OSMC_OpenVPN_Restarter
A simple Kodi addon for kodi v.19, that simple starts a shellscript that stops the OpenVPN service waits 3 seconds and starts it again.
